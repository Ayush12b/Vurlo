import React, { createContext, useContext, useEffect, useState } from "react";
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
  sendPasswordResetEmail,
} from "firebase/auth";
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";

interface AuthContextType {
  user: User | null;
  profileName: string | null;
  profilePhoto: string | null;
  loading: boolean;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, name: string) => Promise<void>;
  logout: () => Promise<void>;
  forgotPassword: (email: string) => Promise<void>;
  updateProfileName: (newName: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profileName, setProfileName] = useState<string | null>(null);
  const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userDoc = await getDoc(doc(db, "users", currentUser.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            setProfileName(data.name || currentUser.displayName || "User");
            setProfilePhoto(
              data.photoURL || currentUser.photoURL || "https://i.pravatar.cc/150?img=3",
            );
          } else {
            setProfileName(currentUser.displayName || "User");
            setProfilePhoto(currentUser.photoURL || "https://i.pravatar.cc/150?img=3");
          }
        } catch (e) {
          console.error("Error fetching user profile:", e);
          setProfileName(currentUser.displayName || "User");
          setProfilePhoto(currentUser.photoURL || "https://i.pravatar.cc/150?img=3");
        }
      } else {
        setProfileName(null);
        setProfilePhoto(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const login = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email, password);
  };

  const signup = async (email: string, password: string, name: string) => {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const currentUser = userCredential.user;
    const defaultAvatar = "https://i.pravatar.cc/150?img=3";

    // Save profile details to Auth Profile
    await updateProfile(currentUser, {
      displayName: name,
      photoURL: defaultAvatar,
    });

    // Save to Firestore users collection
    await setDoc(doc(db, "users", currentUser.uid), {
      name,
      email,
      photoURL: defaultAvatar,
      createdAt: serverTimestamp(),
    });

    setProfileName(name);
    setProfilePhoto(defaultAvatar);
  };

  const logout = async () => {
    await signOut(auth);
  };

  const forgotPassword = async (email: string) => {
    console.log(`[Firebase Auth] Initiating password reset request for: ${email}`);
    try {
      await sendPasswordResetEmail(auth, email);
      console.log(`[Firebase Auth] Password reset email sent successfully to: ${email}`);
    } catch (error: unknown) {
      console.error(`[Firebase Auth] Password reset request failed for ${email}:`, error);
      throw error;
    }
  };

  const updateProfileName = async (newName: string) => {
    const currentUser = auth.currentUser;
    if (!currentUser) throw new Error("No user is logged in");

    // Update Firebase Auth profile displayName
    await updateProfile(currentUser, {
      displayName: newName,
    });

    // Update Firestore users document name
    await setDoc(
      doc(db, "users", currentUser.uid),
      {
        name: newName,
      },
      { merge: true },
    );

    // Update local state
    setProfileName(newName);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profileName,
        profilePhoto,
        loading,
        authModalOpen,
        setAuthModalOpen,
        login,
        signup,
        logout,
        forgotPassword,
        updateProfileName,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
