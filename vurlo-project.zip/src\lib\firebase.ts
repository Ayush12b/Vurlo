import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAr-BiRd-vsBXjPZeq-pgPwCiweXJ26pqE",
  authDomain: "vurlo-d7b0f.firebaseapp.com",
  projectId: "vurlo-d7b0f",
  storageBucket: "vurlo-d7b0f.firebasestorage.app",
  messagingSenderId: "977563913503",
  appId: "1:977563913503:web:ff58711ae7d360c948742a",
};

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
